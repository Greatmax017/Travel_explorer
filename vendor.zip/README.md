# Travel_explorer
Flight booking and hotel reservation platform

#Current Project state
All designs has been rendered to conform with the framework (Laravel)


#booking api
Booking API connection has been made and locked in


#payment api
Flutterwave payment gateway has been integrated and will be tested at the appropirate stage


This readme will continue to be updated for every stage until completion
